require 'rubygems'
require 'sinatra'

set :sessions, true




